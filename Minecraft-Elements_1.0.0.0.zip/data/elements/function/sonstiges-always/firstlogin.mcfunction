execute as @a[scores={elements_playtime=18}] run scoreboard players set @s elements_playerid 0

execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_homedimension 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_techniker_level 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_level_stats 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_start 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_clementius_level 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_interface_number 1
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_autocompactor_stone 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_autocompactor_wood 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_level_enderchest 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_level_autocompact 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_level_tp 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_level_upgradeschmiede 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_level_collections 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_level_settings 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_level_stats 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_level_casino 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_stats_eq 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_miningxp_foresting_level 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_miningxp_fishing_level 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_miningxp_farming_level 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_stats_maxlevel 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_miningxp_mining_level 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_stats_playtime_h 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_stats_playtime_min 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_stats_playtime_sec 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_titus_level 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_stats_lootbox 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_casino_stats_lvlinvestiert 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_casino_stats_lvlgewonnen 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_casino_stats_lvlverloren 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_casino_stats_lvlumsatz 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_casino_stats_game_horse 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_casino_game_horse_timer 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_casino_game 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_casino_config_einsatz 1
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_casino_stats_game_luckywheel 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_casino_interface 1
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_collections_stone_collect 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_collections_stats_stone_total 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_collections_wood_collect 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_collections_stats_wood_total 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_collections_crimson_vines_collect 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_collections_stats_crimson_vines_total 0
#uniques
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_uniqueitem_collections_bruchstueck_der_eismauer 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_uniqueitem_collections_wood 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_uniqueitem_collections_crimson_vines 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_uniqueitem_other_datenspeicher 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_uniqueitem_planetenkern 0

execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_spawn_energiekern_particle_settings 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_settings_tp-mode 1
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_is-assigned-to-dimension 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_collections_interface 1
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_settings_dimension 1
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_settings_gruppengoal_show 1
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_level_shop 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_shop_interface 1
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_shop_count 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_shop_ocean 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_shop_stone 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_shop_sky 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_enderchest_shop_nether 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_mining-frucht_counter 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_mining-frucht_enable 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_mining-frucht_timer_h 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_mining-frucht_timer_min 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_mining-frucht_timer_sec 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_mining-frucht_timer_tick 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_mining-frucht_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_rettungs-plattform_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_rettungs-plattform_cooldown_show 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_foraging-frucht_counter 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_foraging-frucht_enable 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_foraging-frucht_timer_h 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_foraging-frucht_timer_min 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_foraging-frucht_timer_sec 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_foraging-frucht_timer_tick 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_foraging-frucht_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_farming-frucht_counter 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_farming-frucht_enable 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_farming-frucht_timer_h 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_farming-frucht_timer_min 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_farming-frucht_timer_sec 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_farming-frucht_timer_tick 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_farming-frucht_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_fishing-frucht_counter 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_fishing-frucht_enable 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_fishing-frucht_timer_h 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_fishing-frucht_timer_min 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_fishing-frucht_timer_sec 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_fishing-frucht_timer_tick 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_fishing-frucht_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_leveltrank_enable 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_leveltrank_timer_h 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_leveltrank_timer_min 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_leveltrank_timer_sec 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_leveltrank_timer_tick 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_leveltrank_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_leveltrank_counter_stage-1 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_leveltrank_counter_stage-2 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_hastetrank_enable 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_hastetrank_timer_h 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_hastetrank_timer_min 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_hastetrank_timer_sec 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_hastetrank_timer_tick 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_hastetrank_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_water-breathing_enable 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_water-breathing_timer_h 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_water-breathing_timer_min 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_water-breathing_timer_sec 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_water-breathing_timer_tick 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_water-breathing_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_luck-potion_enable 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_luck-potion_timer_h 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_luck-potion_timer_min 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_luck-potion_timer_sec 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_luck-potion_timer_tick 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_boss-frucht_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_boss-frucht_current_stage 1
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_boss-frucht_remain 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_hot-lava_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_manatrank_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_shop_magisches-wasser_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_mystery_tp-schwert_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_mystery_barriere-stab_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom-items_mystery_excalibur_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_stats_fish_caught 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_farm-slots_stage-2_slots 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_farm-slots_stage-2_max-slots 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_farm-slots_stage-3_slots 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_farm-slots_stage-3_max-slots 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_techniker_message_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_get-name_progress 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_get-name_status 0

execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_stats_levellost 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_stats_level_erhalten 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_stats_level_ausgegeben 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_deathcount 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_villager_stage-2_mana_level 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_villager_stage-2_farm-slots_level 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_villager_stage-3_mana_level 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_villager_stage-3_farm-slots_level 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_stage-2_mana_activate_timer_sec 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_stage-2_mana_activate_timer_tick 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_mana_regeneration-per-sec 1
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_mana_mana-max 10
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_mana_mana-count 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_mana_regeneration_timer 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_mana_item_messstab_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_admin_config_interface 1
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_maxhealth 6
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_maxhealth_old 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_custom_doubleclick_cooldown 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_update_sequence_status 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_sonstiges_actionbar_pause 0
execute as @a[scores={elements_playtime=20}] run scoreboard players set @s elements_tokens_count 0


execute as @a[scores={elements_playtime=20}] run scoreboard players operation @s elements_update_sequence_status = .server elements_update_sequence_status


execute as @a[scores={elements_playtime=20}] run scoreboard players add .server elements_playercount 1
execute as @a[scores={elements_playtime=20}] if score .server elements_setup matches 1.. in elements:hub run tp @s 0 101 0

execute as @a[scores={elements_playerid=0},limit=1] run scoreboard players add .server elements_playerid 1
execute as @a[scores={elements_playerid=0},limit=1] run scoreboard players operation @s elements_playerid = .server elements_playerid

execute as @a[scores={elements_playtime=20}] run tellraw @s {"text": "Willkommen in Minecraft Elements!","color":"gold"}
execute as @a[scores={elements_playtime=20}] run title @s title {"text": "MINECRAFT ELEMENTS","color": "light_purple"}
execute as @a[scores={elements_playtime=20}] run title @s subtitle [{"text": "Willkommen, ","color": "dark_purple"},{"selector": "@s","color": "dark_purple"}]

