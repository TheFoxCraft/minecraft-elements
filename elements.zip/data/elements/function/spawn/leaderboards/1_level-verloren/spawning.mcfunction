#/summon minecraft:armor_stand -5.5 100.00 6.5 {Tags:[spawner_leaderboard_id-1]}


summon text_display ~ ~2.7 ~ {billboard:"center",default_background:1b,alignment:"center",Tags:["elements_leaderboard","leaderboard_id-1","leaderboard_id-1_head"],text:'[{"text": "Level Verloren","color": "gold"}]'}
summon text_display ~ ~2.0 ~ {billboard:"center",default_background:1b,alignment:"center",Tags:["elements_leaderboard","leaderboard_id-1","leaderboard_id-1_rang1"],text:'[{"text": "#1 ","color": "gold"},{"text": "%UNSET%","color": "white"},{"text": " - ","color": "white"},{"text": "0","color": "white"}]'}
summon text_display ~ ~1.6 ~ {billboard:"center",default_background:1b,alignment:"center",Tags:["elements_leaderboard","leaderboard_id-1","leaderboard_id-1_rang2"],text:'[{"text": "#2 ","color": "gold"},{"text": "%UNSET%","color": "white"},{"text": " - ","color": "white"},{"text": "0","color": "white"}]'}
summon text_display ~ ~1.2 ~ {billboard:"center",default_background:1b,alignment:"center",Tags:["elements_leaderboard","leaderboard_id-1","leaderboard_id-1_rang3"],text:'[{"text": "#3 ","color": "gold"},{"text": "%UNSET%","color": "white"},{"text": " - ","color": "white"},{"text": "0","color": "white"}]'}
summon text_display ~ ~0.8 ~ {billboard:"center",default_background:1b,alignment:"center",Tags:["elements_leaderboard","leaderboard_id-1","leaderboard_id-1_rang4"],text:'[{"text": "#4 ","color": "gold"},{"text": "%UNSET%","color": "white"},{"text": " - ","color": "white"},{"text": "0","color": "white"}]'}
summon text_display ~ ~0.4 ~ {billboard:"center",default_background:1b,alignment:"center",Tags:["elements_leaderboard","leaderboard_id-1","leaderboard_id-1_rang5"],text:'[{"text": "#5 ","color": "gold"},{"text": "%UNSET%","color": "white"},{"text": " - ","color": "white"},{"text": "0","color": "white"}]'}


kill @s
