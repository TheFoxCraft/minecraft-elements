loot give @s loot elements:items/shops/ocean/bossfrucht/stage_2


